abstract class Animal
{
    //establishes all methods that an animal need plus most common variables.
    abstract void Eat();
    abstract void Breath();
    abstract void Reproduce();
    abstract void Grow();
    abstract void Move();
    abstract void sound();

    public String noise;
    public String huntingMethods;
    public String typeOfReproduction;
    public String timeToMature;
    public String name;
    public String food;
    public String bodyType;
    public String Appendages;
    public String bloodType;

    public int age;
    public int appendages;

    public float size;
    public float weight;
}
