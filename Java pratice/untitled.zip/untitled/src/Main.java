import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        String entry = JOptionPane.showInputDialog("Pizza Order: ");
        PizzaStore pizza = PizzaStore.orderPizza(entry);
        assert pizza != null;
        System.out.println( pizza.getName());
        pizza.prepare();
        pizza.bake();
        pizza.box();
        pizza.cut();


    }
}
