public class PizzaStore {
    //sets the methods so subclass can overrite them this way I can call to order pizza and know iot will return pizza while these
    //methods
    void prepare() {

    }

    void bake() {

    }

    void box() {

    }

    void cut() {

    }
    public String getName() {
        return "";
    }
   static PizzaStore orderPizza(String type) {
        if (type.equals("Chicago")) {
            Chicago newPizza = new Chicago();
            newPizza.name = "Chicago";
            return newPizza;
        }
         else if (type.equals("NY")) {
            NYPizza newPizza = new NYPizza();
            newPizza.name = "NYPizza";
            return newPizza;
        }

        return null;

    }

}
