import java.util.ArrayList;

public interface Shapes {
    double pi = 3.14f;
    double calcArea(ArrayList<Double> dimensions);
    double calcPerim(ArrayList<Double> dimensions);
}
