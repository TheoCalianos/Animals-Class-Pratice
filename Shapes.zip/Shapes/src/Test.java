import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {
    public static void main(String[] arg) {
        Scanner input = new Scanner(System.in);
        Rectangle rectangle = new Rectangle();
        Triangle triangle = new Triangle();
        Circle circle = new Circle();
        System.out.println("would you give the dimensions needed for a rectangle to find its area one at a time please.");
        Double length = input.nextDouble();
        Double width = input.nextDouble();
        rectangle.Adddemsions(length, width);
        System.out.println(rectangle.calcArea(rectangle.dimensions));
        System.out.println("would you give the dimensions needed for a triangle to find its area one at a time please.");
        Double base = input.nextDouble();
        Double height = input.nextDouble();
        triangle.AdddemsionsArea(base, height);
        System.out.println(triangle.calcArea(triangle.dimensions));
        System.out.println("would you give the dimensions needed for a triangle to find its perimeter one at a time please.");
        Double side1 = input.nextDouble();
        Double side2 = input.nextDouble();
        Double side3 = input.nextDouble();
        triangle.addSideLength(side1, side2, side3);
        System.out.println(triangle.calcPerim(triangle.sides));
        System.out.println("would you give the r needed for a circle to find its perimeter one at a time please.");
        Double radius = input.nextDouble();
        circle.Adddemsions(radius);
        System.out.println(circle.calcPerim(circle.dimensions));
        System.out.println(circle.calcPerim(circle.dimensions));
    }
}
