import java.util.ArrayList;

public class Triangle implements Shapes {
    public ArrayList<Double> dimensions = new ArrayList<Double>();
    public ArrayList<Double> sides = new ArrayList<Double>();
    public void AdddemsionsArea(double base, double height)
    {
        dimensions.clear();
        dimensions.add(base);
        dimensions.add(height);
    }
    public void addSideLength(double sideOne, double sideTwo, double sideThree)
    {
        sides.clear();
        sides.add(sideOne);
        sides.add(sideTwo);
        sides.add(sideThree);
    }
    @Override
    public double calcArea(ArrayList<Double> dimensions) {
        double d1 = dimensions.get(0);
        double d2 = dimensions.get(1);
        double area = d1 *d2 *.5;
        return area;
    }

    @Override
    public double calcPerim(ArrayList<Double> sides) {
       double sideOne = sides.get(0);
       double sideTwo = sides.get(1);
       double sideThree = sides.get(2);
       double para = sideOne+sideTwo+sideThree;
       return para;

    }
}
