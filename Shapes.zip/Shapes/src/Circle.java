import java.lang.*;
import java.util.ArrayList;

public class Circle implements Shapes {
    ArrayList<Double> dimensions = new ArrayList<Double>();
    public void Adddemsions(double radius)
    {
        dimensions.clear();
        dimensions.add(radius);
    }
    @Override
    public double calcArea(ArrayList<Double> dimensions) {
        double r = dimensions.get(0);
        return pi*Math.pow(2,r);
    }

    @Override
    public double calcPerim(ArrayList<Double> dimensions) {
        double r = dimensions.get(0);
        return r*2*pi;
    }
}
