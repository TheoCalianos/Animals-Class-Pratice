import java.util.ArrayList;

public class Rectangle implements Shapes {
    ArrayList<Double> dimensions = new ArrayList<Double>();

    public void Adddemsions(double length, double width) {
        dimensions.clear();
        dimensions.add(length);
        dimensions.add(width);
    }

    @Override
    public double calcArea(ArrayList<Double> dimensions) {
        return dimensions.get(0) * dimensions.get(1);
    }

    @Override
    public double calcPerim(ArrayList<Double> dimensions) {
        return (dimensions.get(0) + dimensions.get(1)) * 2;
    }
}