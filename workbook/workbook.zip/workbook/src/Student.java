import java.util.ArrayList;

public class Student {
    ArrayList<Integer> grades = new ArrayList<Integer>();
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public ArrayList<Integer> getGrades() {
        return grades;
    }

    public void setGrade(int grade) {
        grades.add(grade);
    }
    public void getaverage()
    {
        average = 0;
        for(int grade : grades)
        {
            average = average + grade;
        }
        average = average/grades.size();
    }
    String Name = "";
    int average;

}
