package Company;

public class Hourly extends Employee implements Taxform{
    String taxForm =  "w2";

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    int hoursWorked = 40;
    @Override
    double CalculatePay() {
        double taxRate = getTotalTax();
        double hourlyRate = getPayrate();
        double normPay =  hourlyRate * hoursWorked * ((100-taxRate)/100) ;
        if(hoursWorked <= 40) {
            return normPay;
        }
        else
        {
            int overTimeHours = hoursWorked-40;
            normPay = hourlyRate * 40 * ((100-taxRate)/100);
            double overTimePay =  hourlyRate * overTimeHours * ((100-taxRate)/100) * 1.5f;
            return normPay + overTimePay;
        }
    }


    @Override
    public String getTaxForm() {
        return taxForm;
    }

    @Override
    public void setTaxForm(String form) {
        if (form != taxForm) {
            taxForm = form;
        }
    }
}
