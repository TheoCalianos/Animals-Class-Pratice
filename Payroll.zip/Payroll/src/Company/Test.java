package Company;
import java.lang.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Test {
    public static void main(String[] arg)
    {
        Scanner input = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();
        Hourly dave = new Hourly();
        dave.setAge(30);
        dave.setName("Dave");
        dave.setPayrate(15);
        dave.setTotalTax(15);
        dave.setHoursWorked(40);
        System.out.println(dave.getName());
        System.out.println(dave.CalculatePay());
        System.out.println(dave.getPayrate());
        System.out.println(dave.getHoursWorked());
        System.out.println(dave.getTaxForm() + "\n");
        employees.add(dave);

        Salary Theo = new Salary();
        Theo.setBonus(4000);
        Theo.setAge(19);
        Theo.setName("Theo");
        Theo.setPayrate(80000);
        Theo.setTotalTax(15);
        System.out.println(Theo.getName());
        System.out.println(Theo.getTotalTax());
        System.out.println(Theo.CalculatePay());
        System.out.println(Theo.getPayrate());
        System.out.println(Theo.getTaxForm() + "\n");
        employees.add(Theo);

        PerDiem sam = new PerDiem();;
        sam.setAge(19);
        sam.setName("Sam");
        sam.setPayrate(15);
        sam.setHoursWorked(40);
        System.out.println(sam.getName());
        System.out.println(sam.CalculatePay());
        System.out.println(sam.getPayrate());
        System.out.println(sam.getTaxForm());
        employees.add(sam);

        System.out.println("would u like to add or search for employee for search type 1 or add type 2.");
        int number = input.nextInt();
        if(number == 1)
        {
            System.out.println("Please type the name of the employee and info will appear.");
            String name = input.next();
            for(int i = 0; i < employees.size(); i++ )
            {
                 String employName = employees.get(i).getName();
                if(employName.equals(name))
                {
                    System.out.println(employees.get(i).getName());
                    System.out.println(employees.get(i).getPayrate());
                    System.out.println(employees.get(i).getTotalTax());
                    System.out.println(employees.get(i).CalculatePay());
                    if(employees.get(i).getClass().getName().equals("Company.Hourly"))
                    {
                        System.out.println(employees.get(i).getName() + " is Hourly");
                        //compiler is dumb and thinks that the list of employees don't have these methods existing
                        // in them but the code would work if it complied bc it would only run the methods if
                        //the employee is hourly so it would have these methods. But because they are not in the employee class
                        //it can see the methods even tho they are public and i am not rewriting employee to pass
                        //also don't have the time to investigate wrappers which i believe would fix this issue.
                        //down all the methods. this code would work if it was able to run.
                        //System.out.println(employees.get(i).getHoursWorked());
                        //System.out.println(employees.get(i).getTaxForm() + "\n");
                    }
                    else if(employees.get(i).getClass().getName().equals("Company.Salary"))
                    {
                        System.out.println(employees.get(i).getName() + " is Salary");
                     //System.out.println(Theo.getTaxForm() + "\n");
                    }
                    else
                    {
                        System.out.println(employees.get(i).getName() + " is PerDiem");
                    }
                }
            }
        }
        else if(number == 2)
        {
            System.out.println("What is the employee's name");
            String name = input.next();
            System.out.println("What is the employee's age please use whole numbers");
            int age = input.nextInt();
            System.out.println("What Type of employee is it Hourly, Salary, PerDiem.");
            String type = input.next();
            if(type.equalsIgnoreCase("Hourly"))
            {
                Hourly newEmployee = new Hourly();
                newEmployee.setName(name);
                newEmployee.setAge(age);
                System.out.println("what is there rate perhour");
                float hourlyRate = input.nextFloat();
                newEmployee.setPayrate(hourlyRate);
                System.out.println("How many hours did they work");
                int workedHours = input.nextInt();
                newEmployee.setHoursWorked(workedHours);
                newEmployee.setPayrate(hourlyRate);
                System.out.println("what is there taxRate");
                float taxRate = input.nextFloat();
                newEmployee.setPayrate(taxRate);
                System.out.println("This is there calculated pay plus the used tax form");
                System.out.println("The amount they earned after taxes" + newEmployee.CalculatePay());
                System.out.println("thier tax form is" + newEmployee.getTaxForm() + "\n");
            }
            else if(type.equalsIgnoreCase("Salary"))
            {
                Salary newEmployee = new Salary();
                newEmployee.setName(name);
                newEmployee.setAge(age);
                System.out.println("what is there Salary");
                float salary = input.nextFloat();
                newEmployee.setPayrate(salary);
                System.out.println("what is there taxRate");
                float taxRate = input.nextFloat();
                newEmployee.setPayrate(taxRate);
                System.out.println("This is there calculated pay plus the used tax form ");
                System.out.println("The amount they earned after taxes " + newEmployee.CalculatePay());
                System.out.println("thier tax form is " + newEmployee.getTaxForm() + "\n");
            }
            else
            {
                PerDiem newEmployee = new PerDiem();
                newEmployee.setName(name);
                newEmployee.setAge(age);
                System.out.println("what is there rate perhour");
                float hourlyRate = input.nextFloat();
                newEmployee.setPayrate(hourlyRate);
                System.out.println("How many hours did they work");
                int workedHours = input.nextInt();
                newEmployee.setHoursWorked(workedHours);
                newEmployee.setPayrate(hourlyRate);
                System.out.println("This is there calculated pay plus the used tax form");
                System.out.println("The amount they earned after taxes " + newEmployee.CalculatePay());
                System.out.println("their tax form is " + newEmployee.getTaxForm() + "\n");
            }


        }
        else
        {
            System.out.println("plz rerun program your input appears not to be 1 or 2");
        }
    }
}
