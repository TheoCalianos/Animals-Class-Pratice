package Company;

public abstract class Employee implements Person {
    private String employName;
    private int Age;
    private double payRate;
    private double grossSalvery;
    private double totalTax;

    abstract double CalculatePay();

    public double getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

    public double getPayrate() {
        return payRate;
    }

    public void setPayrate(double payRate) {
        this.payRate = payRate;
    }

    @Override
    public void setName(String name) {
        employName = name;
    }

    @Override
    public String getName() {
        return this.employName;
    }

    @Override
    public void setAge(int years) {

    }

    @Override
    public int getAge() {
        return this.Age;
    }

}
