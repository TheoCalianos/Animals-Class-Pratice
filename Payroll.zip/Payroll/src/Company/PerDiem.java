package Company;

public class PerDiem extends Employee implements Taxform{
    String taxForm = "1099";

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    int hoursWorked;
    @Override
    double CalculatePay() {
        double hourlyRate = getPayrate();
        return hourlyRate * hoursWorked;
    }

    @Override
    public String getTaxForm() {
        return taxForm;
    }

    @Override
    public void setTaxForm(String form) {
        if (!form.equals(taxForm)) {
            taxForm = form;
        }
    }
}
