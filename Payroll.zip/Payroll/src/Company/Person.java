package Company;

public interface Person {
    public void setName(String name);
    public String getName();
    public void setAge(int years);
    public int getAge();
}
