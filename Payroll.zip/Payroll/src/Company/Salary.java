package Company;

public class Salary extends Employee implements Taxform {
    String taxForm = "w2";

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    int bonus = 0;
    @Override
    double CalculatePay() {
        double yearlyPay = getPayrate();
        double taxRate = getTotalTax();
        double weeklyPay = yearlyPay/56;
        if(bonus == 0) {
            return yearlyPay * ((100 - taxRate) / 100);
        }
        else
        {
            return (yearlyPay * ((100 - taxRate) / 100) )+ bonus;
        }
    }

    @Override
    public String getTaxForm() {
        return taxForm;
    }

    @Override
    public void setTaxForm(String form) {
        if (form != taxForm) {
            taxForm = form;
        }
    }
}
