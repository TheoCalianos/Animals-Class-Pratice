package Company;

public interface Taxform {
    public String getTaxForm();
    public void setTaxForm(String form);
}
